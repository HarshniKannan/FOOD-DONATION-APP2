import {createContext} from 'react';

export default UserContext = createContext(null)