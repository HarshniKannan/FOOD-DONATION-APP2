# Simple Food Donation app
### Features 
#### 1.) Authentication

 ![Register](https://media.discordapp.net/attachments/694222727791509544/872717952808542238/Screenshot_1628142046.png?width=326&height=670 "Register") ![Login](https://media.discordapp.net/attachments/694222727791509544/872717938883440701/Screenshot_1628142049.png?width=326&height=670 "Login")
#### 2.) Avaliable Foods

<img src = "https://cdn.discordapp.com/attachments/694222727791509544/872717948140257330/Screenshot_1628141786.png" width="326px" height="670px">
#### 3.) Donate Food

<img src = "https://cdn.discordapp.com/attachments/694222727791509544/872717946735190136/Screenshot_1628141791.png" width="326px" height="670px"> <img src = "https://cdn.discordapp.com/attachments/694222727791509544/872717949419532308/Screenshot_1628141825.png" width="326px" height="670px"> <img src = "https://cdn.discordapp.com/attachments/694222727791509544/872717946475122688/Screenshot_1628141822.png" width="326px" height="670px"> <img src = "https://cdn.discordapp.com/attachments/694222727791509544/872717955325120542/Screenshot_1628141910.png" width="326px" height="670px">

#### 4.) Chat 
<img src = "https://cdn.discordapp.com/attachments/694222727791509544/872717940737339453/Screenshot_1628142145.png" width="326px" height="670px">
